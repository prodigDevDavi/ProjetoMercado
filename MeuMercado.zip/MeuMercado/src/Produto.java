/**
 *
 * @author artur
 */
public class Produto
{
    public int id;
    public double valor;
    public String nome;
}
